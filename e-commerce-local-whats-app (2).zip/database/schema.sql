-- ============================================================
-- SHELLS FASHION ELEGANCE - SCRIPT SQL COMPLETO
-- Banco de Dados: MySQL
-- Versão: 1.0
-- Data: Maio 2024
-- País: Moçambique
-- ============================================================

-- Criar o banco de dados
CREATE DATABASE IF NOT EXISTS shells_fashion CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE shells_fashion;

-- ============================================================
-- TABELA: users (Administradores)
-- ============================================================
CREATE TABLE IF NOT EXISTS User (
    id VARCHAR(191) NOT NULL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABELA: Store (Configurações da Loja)
-- ============================================================
CREATE TABLE IF NOT EXISTS Store (
    id VARCHAR(191) NOT NULL PRIMARY KEY,
    name VARCHAR(255) NOT NULL DEFAULT 'Shells Fashion Elegance',
    description TEXT,
    whatsapp VARCHAR(50),
    phone VARCHAR(50),
    email VARCHAR(255),
    address TEXT,
    instagram VARCHAR(255),
    facebook VARCHAR(255),
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABELA: Product (Produtos)
-- ============================================================
CREATE TABLE IF NOT EXISTS Product (
    id VARCHAR(191) NOT NULL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(500),
    category VARCHAR(100) NOT NULL DEFAULT 'outros',
    stock INT NOT NULL DEFAULT 0,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    INDEX idx_product_category (category),
    INDEX idx_product_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABELA: Order (Pedidos)
-- ============================================================
CREATE TABLE IF NOT EXISTS `Order` (
    id VARCHAR(191) NOT NULL PRIMARY KEY,
    customer VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    items TEXT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pendente',
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    INDEX idx_order_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DADOS INICIAIS: Admin
-- Senha: 123456 (hash bcrypt)
-- ============================================================
INSERT INTO User (id, email, password) VALUES 
('admin-001', 'admin@example.com', '$2a$10$rOGxN8VQcRkVQ8z5hTYVyO5JkYV1xPVqNv5ZPmWKQvK7JZ5vZ5vZ5')
ON DUPLICATE KEY UPDATE email = email;

-- ============================================================
-- DADOS INICIAIS: Configurações da Loja
-- ============================================================
INSERT INTO Store (id, name, description, whatsapp, phone, email, address, instagram, facebook) VALUES
('store-001', 
 'Shells Fashion Elegance', 
 'A melhor loja de moda elegante de Moçambique. Qualidade premium e atendimento excepcional.',
 '+258879992762',
 '847052762',
 'shells@fashion.com',
 'Khongolote, Maputo, Moçambique',
 '@shellsfashion',
 'shellsfashionmz')
ON DUPLICATE KEY UPDATE name = name;

-- ============================================================
-- DADOS INICIAIS: Produtos de Exemplo (Preços em Meticais - MT)
-- ============================================================
INSERT INTO Product (id, name, description, price, image, category, stock, active) VALUES
('prod-001', 'Blazer Premium', 'Blazer elegante em tecido premium, perfeito para ocasiões especiais. Corte moderno e acabamento impecável.', 4500.00, '/images/blazer.jpg', 'roupas', 15, TRUE),
('prod-002', 'Vestido Elegante', 'Vestido sofisticado com design exclusivo. Ideal para eventos formais e festas elegantes.', 5800.00, '/images/vestido.jpg', 'roupas', 10, TRUE),
('prod-003', 'Bolsa Luxo', 'Bolsa de couro genuíno com acabamento premium. Acessório indispensável para mulheres de estilo.', 3200.00, '/images/bolsa.jpg', 'acessorios', 20, TRUE),
('prod-004', 'Sapato Alto', 'Sapato de salto alto em couro italiano. Conforto e elegância em cada passo.', 2800.00, '/images/sapato.jpg', 'sapatos', 25, TRUE),
('prod-005', 'Colar Pérolas', 'Colar de pérolas naturais com fecho em ouro. Joia atemporal para mulheres sofisticadas.', 6500.00, '/images/colar.jpg', 'acessorios', 8, TRUE),
('prod-006', 'Calça Social', 'Calça social em tecido premium com corte alfaiataria. Versatilidade e elegância.', 2400.00, '/images/calca.jpg', 'roupas', 30, TRUE)
ON DUPLICATE KEY UPDATE name = name;

-- ============================================================
-- VIEWS ÚTEIS
-- ============================================================

-- View de produtos ativos
CREATE OR REPLACE VIEW vw_produtos_ativos AS
SELECT id, name, description, price, image, category, stock
FROM Product
WHERE active = TRUE AND stock > 0
ORDER BY createdAt DESC;

-- View de pedidos pendentes
CREATE OR REPLACE VIEW vw_pedidos_pendentes AS
SELECT id, customer, phone, total, status, createdAt
FROM `Order`
WHERE status = 'pendente'
ORDER BY createdAt DESC;

-- View de estatísticas
CREATE OR REPLACE VIEW vw_estatisticas AS
SELECT 
    (SELECT COUNT(*) FROM Product WHERE active = TRUE) as total_produtos,
    (SELECT COUNT(*) FROM `Order`) as total_pedidos,
    (SELECT COUNT(*) FROM `Order` WHERE status = 'pendente') as pedidos_pendentes,
    (SELECT COALESCE(SUM(total), 0) FROM `Order` WHERE status = 'entregue') as receita_total;

-- ============================================================
-- PROCEDIMENTOS ARMAZENADOS
-- ============================================================

-- Procedimento para criar novo pedido
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_criar_pedido(
    IN p_id VARCHAR(191),
    IN p_customer VARCHAR(255),
    IN p_phone VARCHAR(50),
    IN p_items TEXT,
    IN p_total DECIMAL(10,2)
)
BEGIN
    INSERT INTO `Order` (id, customer, phone, items, total, status)
    VALUES (p_id, p_customer, p_phone, p_items, p_total, 'pendente');
END //
DELIMITER ;

-- Procedimento para atualizar status do pedido
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_atualizar_status_pedido(
    IN p_id VARCHAR(191),
    IN p_status VARCHAR(50)
)
BEGIN
    UPDATE `Order` SET status = p_status WHERE id = p_id;
END //
DELIMITER ;

-- ============================================================
-- TRIGGERS
-- ============================================================

-- Trigger para atualizar estoque após pedido
DELIMITER //
CREATE TRIGGER IF NOT EXISTS trg_atualizar_estoque_apos_pedido
AFTER INSERT ON `Order`
FOR EACH ROW
BEGIN
    -- Lógica para decrementar estoque será implementada via aplicação
    -- devido à complexidade do JSON de items
END //
DELIMITER ;

-- ============================================================
-- ÍNDICES ADICIONAIS PARA PERFORMANCE
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_product_name ON Product(name);
CREATE INDEX IF NOT EXISTS idx_order_customer ON `Order`(customer);
CREATE INDEX IF NOT EXISTS idx_order_created ON `Order`(createdAt);

-- ============================================================
-- GRANT DE PERMISSÕES (ajuste conforme necessário)
-- ============================================================
-- GRANT ALL PRIVILEGES ON shells_fashion.* TO 'seu_usuario'@'localhost';
-- FLUSH PRIVILEGES;

-- ============================================================
-- MENSAGEM FINAL
-- ============================================================
SELECT '=====================================================' AS '';
SELECT 'SHELLS FASHION ELEGANCE - BANCO CRIADO COM SUCESSO!' AS '';
SELECT '=====================================================' AS '';
SELECT 'Admin: admin@example.com | Senha: 123456' AS '';
SELECT 'País: Moçambique | Moeda: Meticais (MT)' AS '';
SELECT 'WhatsApp: +258 879 992 762' AS '';
SELECT 'Localização: Khongolote, Maputo' AS '';
SELECT '=====================================================' AS '';

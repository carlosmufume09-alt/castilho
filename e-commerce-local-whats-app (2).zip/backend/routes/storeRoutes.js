const express = require('express');
const router = express.Router();
const storeController = require('../controllers/storeController');
const authMiddleware = require('../middlewares/authMiddleware');

// Rotas públicas
router.get('/', storeController.getStore);

// Rotas protegidas (admin)
router.put('/', authMiddleware, storeController.updateStore);

module.exports = router;

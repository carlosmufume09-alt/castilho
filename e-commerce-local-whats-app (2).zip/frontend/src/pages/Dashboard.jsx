import { useState, useEffect } from 'react'
import { useNavigate, Routes, Route, Link, useLocation } from 'react-router-dom'
import axios from 'axios'

// ============================================
// SHELLS FASHION ELEGANCE - ADMIN DASHBOARD
// Moçambique - Khongolote, Maputo
// Moeda: Meticais (MT)
// Tudo em um único arquivo JSX
// ============================================

const API_URL = 'http://localhost:5000/api'

// ============================================
// ESTILOS CSS (Inline)
// ============================================
const styles = {
  // Layout Principal
  container: {
    display: 'flex',
    minHeight: '100vh',
    fontFamily: "'Inter', sans-serif",
    backgroundColor: '#f8f9fa'
  },
  
  // Sidebar
  sidebar: {
    width: '260px',
    background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 50%, #9F7AEA 100%)',
    color: 'white',
    padding: '0',
    position: 'fixed',
    height: '100vh',
    boxShadow: '4px 0 20px rgba(107, 70, 193, 0.3)',
    display: 'flex',
    flexDirection: 'column'
  },
  
  sidebarHeader: {
    padding: '30px 20px',
    borderBottom: '1px solid rgba(255,255,255,0.1)',
    textAlign: 'center'
  },
  
  logo: {
    fontSize: '24px',
    fontWeight: '700',
    fontFamily: "'Playfair Display', serif",
    marginBottom: '5px'
  },
  
  logoSub: {
    fontSize: '12px',
    opacity: '0.8',
    letterSpacing: '2px',
    textTransform: 'uppercase'
  },
  
  nav: {
    padding: '20px 0',
    flex: 1
  },
  
  navItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '14px 24px',
    color: 'rgba(255,255,255,0.8)',
    textDecoration: 'none',
    fontSize: '15px',
    transition: 'all 0.3s ease',
    borderLeft: '3px solid transparent',
    cursor: 'pointer'
  },
  
  navItemActive: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '14px 24px',
    color: 'white',
    textDecoration: 'none',
    fontSize: '15px',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderLeft: '3px solid white',
    cursor: 'pointer'
  },
  
  navIcon: {
    fontSize: '20px',
    width: '24px',
    textAlign: 'center'
  },
  
  // Main Content
  mainContent: {
    flex: 1,
    marginLeft: '260px',
    padding: '30px',
    minHeight: '100vh'
  },
  
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '30px',
    padding: '20px 25px',
    backgroundColor: 'white',
    borderRadius: '16px',
    boxShadow: '0 2px 12px rgba(0,0,0,0.06)'
  },
  
  pageTitle: {
    fontSize: '28px',
    fontWeight: '700',
    color: '#1a1a2e',
    fontFamily: "'Playfair Display', serif"
  },
  
  // Cards de Estatísticas
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: '20px',
    marginBottom: '30px'
  },
  
  statCard: {
    backgroundColor: 'white',
    borderRadius: '16px',
    padding: '25px',
    boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease'
  },
  
  statCardPurple: {
    backgroundColor: '#6B46C1',
    color: 'white'
  },
  
  statCardGreen: {
    backgroundColor: '#38A169',
    color: 'white'
  },
  
  statCardOrange: {
    backgroundColor: '#DD6B20',
    color: 'white'
  },
  
  statCardBlue: {
    backgroundColor: '#3182CE',
    color: 'white'
  },
  
  statIcon: {
    fontSize: '32px',
    marginBottom: '15px'
  },
  
  statValue: {
    fontSize: '32px',
    fontWeight: '700',
    marginBottom: '5px'
  },
  
  statLabel: {
    fontSize: '14px',
    opacity: '0.9'
  },
  
  // Tabelas
  table: {
    width: '100%',
    backgroundColor: 'white',
    borderRadius: '16px',
    overflow: 'hidden',
    boxShadow: '0 2px 12px rgba(0,0,0,0.06)'
  },
  
  tableHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px 25px',
    borderBottom: '1px solid #eee'
  },
  
  tableTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#1a1a2e'
  },
  
  th: {
    padding: '15px 20px',
    textAlign: 'left',
    backgroundColor: '#f8f9fa',
    fontWeight: '600',
    fontSize: '13px',
    color: '#666',
    textTransform: 'uppercase',
    letterSpacing: '0.5px'
  },
  
  td: {
    padding: '18px 20px',
    borderBottom: '1px solid #f0f0f0',
    fontSize: '14px',
    color: '#333'
  },
  
  // Botões
  button: {
    padding: '12px 24px',
    borderRadius: '10px',
    border: 'none',
    cursor: 'pointer',
    fontWeight: '600',
    fontSize: '14px',
    transition: 'all 0.3s ease',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px'
  },
  
  buttonPrimary: {
    background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 100%)',
    color: 'white'
  },
  
  buttonSecondary: {
    backgroundColor: '#f0f0f0',
    color: '#333'
  },
  
  buttonDanger: {
    backgroundColor: '#E53E3E',
    color: 'white'
  },
  
  buttonSmall: {
    padding: '8px 16px',
    fontSize: '13px'
  },
  
  // Forms
  formGroup: {
    marginBottom: '20px'
  },
  
  label: {
    display: 'block',
    marginBottom: '8px',
    fontWeight: '500',
    fontSize: '14px',
    color: '#333'
  },
  
  input: {
    width: '100%',
    padding: '14px 16px',
    borderRadius: '10px',
    border: '2px solid #e0e0e0',
    fontSize: '15px',
    transition: 'border-color 0.3s ease',
    boxSizing: 'border-box',
    outline: 'none'
  },
  
  textarea: {
    width: '100%',
    padding: '14px 16px',
    borderRadius: '10px',
    border: '2px solid #e0e0e0',
    fontSize: '15px',
    minHeight: '120px',
    resize: 'vertical',
    boxSizing: 'border-box',
    outline: 'none',
    fontFamily: "'Inter', sans-serif"
  },
  
  select: {
    width: '100%',
    padding: '14px 16px',
    borderRadius: '10px',
    border: '2px solid #e0e0e0',
    fontSize: '15px',
    backgroundColor: 'white',
    cursor: 'pointer',
    outline: 'none'
  },
  
  // Modal
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  
  modal: {
    backgroundColor: 'white',
    borderRadius: '20px',
    padding: '30px',
    width: '500px',
    maxWidth: '90%',
    maxHeight: '90vh',
    overflow: 'auto',
    boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
  },
  
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '25px',
    paddingBottom: '15px',
    borderBottom: '1px solid #eee'
  },
  
  modalTitle: {
    fontSize: '22px',
    fontWeight: '700',
    color: '#1a1a2e'
  },
  
  closeButton: {
    background: 'none',
    border: 'none',
    fontSize: '28px',
    cursor: 'pointer',
    color: '#999',
    padding: '0',
    lineHeight: '1'
  },
  
  // Badges/Status
  badge: {
    padding: '6px 14px',
    borderRadius: '20px',
    fontSize: '12px',
    fontWeight: '600',
    display: 'inline-block'
  },
  
  badgePending: {
    backgroundColor: '#FEF3C7',
    color: '#D97706'
  },
  
  badgeConfirmed: {
    backgroundColor: '#DBEAFE',
    color: '#2563EB'
  },
  
  badgeShipped: {
    backgroundColor: '#E0E7FF',
    color: '#4F46E5'
  },
  
  badgeDelivered: {
    backgroundColor: '#D1FAE5',
    color: '#059669'
  },
  
  badgeCancelled: {
    backgroundColor: '#FEE2E2',
    color: '#DC2626'
  },
  
  // Footer Sidebar
  sidebarFooter: {
    padding: '20px',
    borderTop: '1px solid rgba(255,255,255,0.1)',
    fontSize: '12px',
    opacity: '0.7',
    textAlign: 'center'
  },
  
  // Empty State
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    color: '#999'
  },
  
  emptyIcon: {
    fontSize: '64px',
    marginBottom: '20px',
    opacity: '0.5'
  },
  
  // Actions
  actions: {
    display: 'flex',
    gap: '8px'
  }
}

// ============================================
// COMPONENTES
// ============================================

// Componente de Loading
const Loading = () => (
  <div style={{ textAlign: 'center', padding: '60px', color: '#666' }}>
    <div style={{ fontSize: '48px', marginBottom: '20px' }}>⏳</div>
    <p>Carregando...</p>
  </div>
)

// Componente de Status Badge
const StatusBadge = ({ status }) => {
  const statusStyles = {
    pendente: styles.badgePending,
    confirmado: styles.badgeConfirmed,
    enviado: styles.badgeShipped,
    entregue: styles.badgeDelivered,
    cancelado: styles.badgeCancelled
  }
  
  const statusLabels = {
    pendente: 'Pendente',
    confirmado: 'Confirmado',
    enviado: 'Enviado',
    entregue: 'Entregue',
    cancelado: 'Cancelado'
  }
  
  return (
    <span style={{ ...styles.badge, ...statusStyles[status] }}>
      {statusLabels[status] || status}
    </span>
  )
}

// ============================================
// PÁGINA PRINCIPAL - DASHBOARD
// ============================================
const DashboardHome = ({ stats }) => (
  <div>
    <div style={styles.statsGrid}>
      <div style={{ ...styles.statCard, ...styles.statCardPurple }}>
        <div style={styles.statIcon}>📦</div>
        <div style={styles.statValue}>{stats.totalProducts}</div>
        <div style={styles.statLabel}>Total de Produtos</div>
      </div>
      
      <div style={{ ...styles.statCard, ...styles.statCardGreen }}>
        <div style={styles.statIcon}>🛒</div>
        <div style={styles.statValue}>{stats.totalOrders}</div>
        <div style={styles.statLabel}>Total de Pedidos</div>
      </div>
      
      <div style={{ ...styles.statCard, ...styles.statCardOrange }}>
        <div style={styles.statIcon}>⏰</div>
        <div style={styles.statValue}>{stats.pendingOrders}</div>
        <div style={styles.statLabel}>Pedidos Pendentes</div>
      </div>
      
      <div style={{ ...styles.statCard, ...styles.statCardBlue }}>
        <div style={styles.statIcon}>💰</div>
        <div style={styles.statValue}>MT {stats.totalRevenue.toFixed(2)}</div>
        <div style={styles.statLabel}>Receita Total</div>
      </div>
    </div>
    
    <div style={styles.table}>
      <div style={styles.tableHeader}>
        <h3 style={styles.tableTitle}>Informações da Loja</h3>
      </div>
      <div style={{ padding: '25px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
          <div>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '5px' }}>WhatsApp</p>
            <p style={{ fontWeight: '600', fontSize: '16px' }}>+258 879 992 762</p>
          </div>
          <div>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '5px' }}>Telefone</p>
            <p style={{ fontWeight: '600', fontSize: '16px' }}>847 052 762</p>
          </div>
          <div>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '5px' }}>Localização</p>
            <p style={{ fontWeight: '600', fontSize: '16px' }}>Khongolote, Maputo, Moçambique</p>
          </div>
          <div>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '5px' }}>Moeda</p>
            <p style={{ fontWeight: '600', fontSize: '16px' }}>Meticais (MT)</p>
          </div>
        </div>
      </div>
    </div>
  </div>
)

// ============================================
// PÁGINA DE PRODUTOS
// ============================================
const ProductsPage = ({ products, onAdd, onEdit, onDelete, loading }) => {
  const [showModal, setShowModal] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: 'roupas',
    stock: ''
  })
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (editingProduct) {
      await onEdit(editingProduct.id, formData)
    } else {
      await onAdd(formData)
    }
    setShowModal(false)
    setEditingProduct(null)
    setFormData({ name: '', description: '', price: '', category: 'roupas', stock: '' })
  }
  
  const openEdit = (product) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      category: product.category,
      stock: product.stock
    })
    setShowModal(true)
  }
  
  const openAdd = () => {
    setEditingProduct(null)
    setFormData({ name: '', description: '', price: '', category: 'roupas', stock: '' })
    setShowModal(true)
  }
  
  return (
    <div>
      <div style={styles.table}>
        <div style={styles.tableHeader}>
          <h3 style={styles.tableTitle}>Lista de Produtos</h3>
          <button 
            style={{ ...styles.button, ...styles.buttonPrimary }}
            onClick={openAdd}
          >
            ➕ Novo Produto
          </button>
        </div>
        
        {loading ? (
          <Loading />
        ) : products.length === 0 ? (
          <div style={styles.emptyState}>
            <div style={styles.emptyIcon}>📦</div>
            <p>Nenhum produto cadastrado</p>
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={styles.th}>Produto</th>
                <th style={styles.th}>Categoria</th>
                <th style={styles.th}>Preço (MT)</th>
                <th style={styles.th}>Estoque</th>
                <th style={styles.th}>Ações</th>
              </tr>
            </thead>
            <tbody>
              {products.map(product => (
                <tr key={product.id}>
                  <td style={styles.td}>
                    <div style={{ fontWeight: '600' }}>{product.name}</div>
                    <div style={{ fontSize: '13px', color: '#666', marginTop: '4px' }}>
                      {product.description?.substring(0, 50)}...
                    </div>
                  </td>
                  <td style={styles.td}>{product.category}</td>
                  <td style={styles.td}>
                    <span style={{ fontWeight: '600', color: '#6B46C1' }}>
                      MT {parseFloat(product.price).toFixed(2)}
                    </span>
                  </td>
                  <td style={styles.td}>{product.stock}</td>
                  <td style={styles.td}>
                    <div style={styles.actions}>
                      <button 
                        style={{ ...styles.button, ...styles.buttonSecondary, ...styles.buttonSmall }}
                        onClick={() => openEdit(product)}
                      >
                        ✏️
                      </button>
                      <button 
                        style={{ ...styles.button, ...styles.buttonDanger, ...styles.buttonSmall }}
                        onClick={() => onDelete(product.id)}
                      >
                        🗑️
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      {/* Modal de Produto */}
      {showModal && (
        <div style={styles.modalOverlay} onClick={() => setShowModal(false)}>
          <div style={styles.modal} onClick={e => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <h2 style={styles.modalTitle}>
                {editingProduct ? 'Editar Produto' : 'Novo Produto'}
              </h2>
              <button style={styles.closeButton} onClick={() => setShowModal(false)}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Nome do Produto</label>
                <input
                  style={styles.input}
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  required
                  placeholder="Ex: Blazer Elegante"
                />
              </div>
              
              <div style={styles.formGroup}>
                <label style={styles.label}>Descrição</label>
                <textarea
                  style={styles.textarea}
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  placeholder="Descreva o produto..."
                />
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Preço (MT)</label>
                  <input
                    style={styles.input}
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={e => setFormData({...formData, price: e.target.value})}
                    required
                    placeholder="0.00"
                  />
                </div>
                
                <div style={styles.formGroup}>
                  <label style={styles.label}>Estoque</label>
                  <input
                    style={styles.input}
                    type="number"
                    value={formData.stock}
                    onChange={e => setFormData({...formData, stock: e.target.value})}
                    placeholder="0"
                  />
                </div>
              </div>
              
              <div style={styles.formGroup}>
                <label style={styles.label}>Categoria</label>
                <select
                  style={styles.select}
                  value={formData.category}
                  onChange={e => setFormData({...formData, category: e.target.value})}
                >
                  <option value="roupas">Roupas</option>
                  <option value="sapatos">Sapatos</option>
                  <option value="acessorios">Acessórios</option>
                  <option value="bolsas">Bolsas</option>
                  <option value="outros">Outros</option>
                </select>
              </div>
              
              <div style={{ display: 'flex', gap: '10px', marginTop: '25px' }}>
                <button 
                  type="button"
                  style={{ ...styles.button, ...styles.buttonSecondary, flex: 1 }}
                  onClick={() => setShowModal(false)}
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  style={{ ...styles.button, ...styles.buttonPrimary, flex: 1 }}
                >
                  {editingProduct ? 'Salvar' : 'Criar Produto'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================
// PÁGINA DE PEDIDOS
// ============================================
const OrdersPage = ({ orders, onUpdateStatus, onDelete, loading }) => {
  return (
    <div style={styles.table}>
      <div style={styles.tableHeader}>
        <h3 style={styles.tableTitle}>Lista de Pedidos</h3>
      </div>
      
      {loading ? (
        <Loading />
      ) : orders.length === 0 ? (
        <div style={styles.emptyState}>
          <div style={styles.emptyIcon}>🛒</div>
          <p>Nenhum pedido registrado</p>
        </div>
      ) : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th style={styles.th}>Cliente</th>
              <th style={styles.th}>Telefone</th>
              <th style={styles.th}>Items</th>
              <th style={styles.th}>Total (MT)</th>
              <th style={styles.th}>Status</th>
              <th style={styles.th}>Ações</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(order => {
              let items = []
              try {
                items = JSON.parse(order.items)
              } catch (e) {
                items = []
              }
              
              return (
                <tr key={order.id}>
                  <td style={styles.td}>
                    <div style={{ fontWeight: '600' }}>{order.customer}</div>
                  </td>
                  <td style={styles.td}>{order.phone}</td>
                  <td style={styles.td}>
                    {items.map((item, idx) => (
                      <div key={idx} style={{ fontSize: '13px' }}>
                        {item.name} x{item.quantity}
                      </div>
                    ))}
                  </td>
                  <td style={styles.td}>
                    <span style={{ fontWeight: '600', color: '#38A169' }}>
                      MT {parseFloat(order.total).toFixed(2)}
                    </span>
                  </td>
                  <td style={styles.td}>
                    <StatusBadge status={order.status} />
                  </td>
                  <td style={styles.td}>
                    <div style={styles.actions}>
                      <select
                        style={{ ...styles.select, width: 'auto', padding: '8px 12px', fontSize: '13px' }}
                        value={order.status}
                        onChange={e => onUpdateStatus(order.id, e.target.value)}
                      >
                        <option value="pendente">Pendente</option>
                        <option value="confirmado">Confirmado</option>
                        <option value="enviado">Enviado</option>
                        <option value="entregue">Entregue</option>
                        <option value="cancelado">Cancelado</option>
                      </select>
                      <button 
                        style={{ ...styles.button, ...styles.buttonDanger, ...styles.buttonSmall }}
                        onClick={() => onDelete(order.id)}
                      >
                        🗑️
                      </button>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ============================================
// PÁGINA DE CONFIGURAÇÕES
// ============================================
const SettingsPage = ({ store, onSave }) => {
  const [formData, setFormData] = useState({
    name: store.name || 'Shells Fashion Elegance',
    description: store.description || '',
    whatsapp: store.whatsapp || '+258879992762',
    phone: store.phone || '847052762',
    email: store.email || 'shells@fashion.com',
    address: store.address || 'Khongolote, Maputo, Moçambique'
  })
  
  useEffect(() => {
    setFormData({
      name: store.name || 'Shells Fashion Elegance',
      description: store.description || '',
      whatsapp: store.whatsapp || '+258879992762',
      phone: store.phone || '847052762',
      email: store.email || 'shells@fashion.com',
      address: store.address || 'Khongolote, Maputo, Moçambique'
    })
  }, [store])
  
  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(formData)
  }
  
  return (
    <div style={styles.table}>
      <div style={styles.tableHeader}>
        <h3 style={styles.tableTitle}>Configurações da Loja</h3>
      </div>
      
      <form onSubmit={handleSubmit} style={{ padding: '25px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Nome da Loja</label>
            <input
              style={styles.input}
              type="text"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Email</label>
            <input
              style={styles.input}
              type="email"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>WhatsApp</label>
            <input
              style={styles.input}
              type="text"
              value={formData.whatsapp}
              onChange={e => setFormData({...formData, whatsapp: e.target.value})}
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Telefone</label>
            <input
              style={styles.input}
              type="text"
              value={formData.phone}
              onChange={e => setFormData({...formData, phone: e.target.value})}
            />
          </div>
        </div>
        
        <div style={styles.formGroup}>
          <label style={styles.label}>Endereço</label>
          <input
            style={styles.input}
            type="text"
            value={formData.address}
            onChange={e => setFormData({...formData, address: e.target.value})}
          />
        </div>
        
        <div style={styles.formGroup}>
          <label style={styles.label}>Descrição</label>
          <textarea
            style={styles.textarea}
            value={formData.description}
            onChange={e => setFormData({...formData, description: e.target.value})}
          />
        </div>
        
        <button 
          type="submit"
          style={{ ...styles.button, ...styles.buttonPrimary, marginTop: '10px' }}
        >
          💾 Salvar Configurações
        </button>
      </form>
    </div>
  )
}

// ============================================
// COMPONENTE PRINCIPAL DO DASHBOARD
// ============================================
export default function Dashboard() {
  const navigate = useNavigate()
  const location = useLocation()
  
  // Estados
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    totalRevenue: 0
  })
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [store, setStore] = useState({})
  
  // Verificar autenticação
  useEffect(() => {
    const token = localStorage.getItem('adminToken')
    if (!token) {
      navigate('/login')
      return
    }
    
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
    setIsAuthenticated(true)
    loadData()
  }, [navigate])
  
  // Carregar dados
  const loadData = async () => {
    setLoading(true)
    try {
      const [statsRes, productsRes, ordersRes, storeRes] = await Promise.all([
        axios.get(`${API_URL}/orders/stats`),
        axios.get(`${API_URL}/products`),
        axios.get(`${API_URL}/orders`),
        axios.get(`${API_URL}/store`)
      ])
      
      setStats(statsRes.data.data)
      setProducts(productsRes.data.data)
      setOrders(ordersRes.data.data)
      setStore(storeRes.data.data)
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    } finally {
      setLoading(false)
    }
  }
  
  // Logout
  const handleLogout = () => {
    localStorage.removeItem('adminToken')
    delete axios.defaults.headers.common['Authorization']
    navigate('/login')
  }
  
  // CRUD Produtos
  const handleAddProduct = async (data) => {
    try {
      await axios.post(`${API_URL}/products`, data)
      loadData()
    } catch (error) {
      alert('Erro ao adicionar produto')
    }
  }
  
  const handleEditProduct = async (id, data) => {
    try {
      await axios.put(`${API_URL}/products/${id}`, data)
      loadData()
    } catch (error) {
      alert('Erro ao editar produto')
    }
  }
  
  const handleDeleteProduct = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este produto?')) {
      try {
        await axios.delete(`${API_URL}/products/${id}`)
        loadData()
      } catch (error) {
        alert('Erro ao excluir produto')
      }
    }
  }
  
  // CRUD Pedidos
  const handleUpdateOrderStatus = async (id, status) => {
    try {
      await axios.put(`${API_URL}/orders/${id}/status`, { status })
      loadData()
    } catch (error) {
      alert('Erro ao atualizar status')
    }
  }
  
  const handleDeleteOrder = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este pedido?')) {
      try {
        await axios.delete(`${API_URL}/orders/${id}`)
        loadData()
      } catch (error) {
        alert('Erro ao excluir pedido')
      }
    }
  }
  
  // Salvar configurações
  const handleSaveStore = async (data) => {
    try {
      await axios.put(`${API_URL}/store`, data)
      setStore(data)
      alert('Configurações salvas com sucesso!')
    } catch (error) {
      alert('Erro ao salvar configurações')
    }
  }
  
  // Verificar página atual
  const currentPath = location.pathname.replace('/admin', '') || '/'
  
  // Navegação
  const navItems = [
    { path: '/', label: 'Dashboard', icon: '📊' },
    { path: '/products', label: 'Produtos', icon: '📦' },
    { path: '/orders', label: 'Pedidos', icon: '🛒' },
    { path: '/settings', label: 'Configurações', icon: '⚙️' }
  ]
  
  if (!isAuthenticated) {
    return <Loading />
  }
  
  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <aside style={styles.sidebar}>
        <div style={styles.sidebarHeader}>
          <div style={styles.logo}>Shells Fashion</div>
          <div style={styles.logoSub}>Admin Panel</div>
        </div>
        
        <nav style={styles.nav}>
          {navItems.map(item => (
            <Link
              key={item.path}
              to={`/admin${item.path === '/' ? '' : item.path}`}
              style={currentPath === item.path ? styles.navItemActive : styles.navItem}
            >
              <span style={styles.navIcon}>{item.icon}</span>
              {item.label}
            </Link>
          ))}
          
          <div
            style={{ ...styles.navItem, marginTop: '20px', color: '#FEB2B2' }}
            onClick={handleLogout}
          >
            <span style={styles.navIcon}>🚪</span>
            Sair
          </div>
        </nav>
        
        <div style={styles.sidebarFooter}>
          <p>Moçambique</p>
          <p>Khongolote, Maputo</p>
        </div>
      </aside>
      
      {/* Main Content */}
      <main style={styles.mainContent}>
        <div style={styles.header}>
          <h1 style={styles.pageTitle}>
            {currentPath === '/' && 'Dashboard'}
            {currentPath === '/products' && 'Produtos'}
            {currentPath === '/orders' && 'Pedidos'}
            {currentPath === '/settings' && 'Configurações'}
          </h1>
          <div style={{ color: '#666', fontSize: '14px' }}>
            Bem-vindo ao painel administrativo
          </div>
        </div>
        
        <Routes>
          <Route path="/" element={<DashboardHome stats={stats} />} />
          <Route 
            path="/products" 
            element={
              <ProductsPage 
                products={products}
                onAdd={handleAddProduct}
                onEdit={handleEditProduct}
                onDelete={handleDeleteProduct}
                loading={loading}
              />
            } 
          />
          <Route 
            path="/orders" 
            element={
              <OrdersPage 
                orders={orders}
                onUpdateStatus={handleUpdateOrderStatus}
                onDelete={handleDeleteOrder}
                loading={loading}
              />
            } 
          />
          <Route 
            path="/settings" 
            element={
              <SettingsPage 
                store={store}
                onSave={handleSaveStore}
              />
            } 
          />
        </Routes>
      </main>
    </div>
  )
}

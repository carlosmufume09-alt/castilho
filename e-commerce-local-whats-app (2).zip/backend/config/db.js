const mysql = require('mysql2/promise');
require('dotenv').config();

let pool;

const connectDB = async () => {
  try {
    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'shells_fashion',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });

    // Testar conexão
    const connection = await pool.getConnection();
    console.log('✓ Conectado ao MySQL - Database: ' + (process.env.DB_NAME || 'shells_fashion'));
    connection.release();

    return pool;
  } catch (error) {
    console.error('Erro ao conectar ao MySQL:', error.message);
    throw error;
  }
};

const getPool = () => {
  if (!pool) {
    throw new Error('Database não inicializado. Chame connectDB() primeiro.');
  }
  return pool;
};

// Query helper
const query = async (sql, params = []) => {
  const pool = getPool();
  const [rows] = await pool.execute(sql, params);
  return rows;
};

module.exports = { connectDB, getPool, query };

const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const authMiddleware = require('../middlewares/authMiddleware');

// Rotas públicas
router.post('/', orderController.create);

// Rotas protegidas (admin)
router.get('/', authMiddleware, orderController.getAll);
router.get('/stats', authMiddleware, orderController.getStats);
router.get('/:id', authMiddleware, orderController.getById);
router.put('/:id/status', authMiddleware, orderController.updateStatus);
router.delete('/:id', authMiddleware, orderController.delete);

module.exports = router;

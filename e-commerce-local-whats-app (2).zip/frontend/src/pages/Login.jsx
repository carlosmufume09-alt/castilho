import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import axios from 'axios'

const API_URL = 'http://localhost:5000/api'

export default function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('admin@example.com')
  const [password, setPassword] = useState('123456')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const res = await axios.post(`${API_URL}/auth/login`, { email, password })
      
      if (res.data.success) {
        localStorage.setItem('adminToken', res.data.token)
        navigate('/admin')
      } else {
        setError(res.data.error || 'Erro ao fazer login')
      }
    } catch (error) {
      setError(error.response?.data?.error || 'Erro ao conectar com o servidor')
    } finally {
      setLoading(false)
    }
  }

  const styles = {
    container: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 50%, #9F7AEA 100%)',
      fontFamily: "'Inter', sans-serif",
      padding: '20px'
    },
    card: {
      backgroundColor: 'white',
      borderRadius: '24px',
      padding: '50px 40px',
      width: '100%',
      maxWidth: '420px',
      boxShadow: '0 25px 50px rgba(0,0,0,0.25)'
    },
    header: {
      textAlign: 'center',
      marginBottom: '35px'
    },
    logo: {
      fontSize: '32px',
      fontWeight: '700',
      fontFamily: "'Playfair Display', serif",
      color: '#6B46C1',
      marginBottom: '8px'
    },
    subtitle: {
      color: '#666',
      fontSize: '15px'
    },
    formGroup: {
      marginBottom: '22px'
    },
    label: {
      display: 'block',
      marginBottom: '10px',
      fontWeight: '500',
      fontSize: '14px',
      color: '#333'
    },
    input: {
      width: '100%',
      padding: '16px 18px',
      borderRadius: '12px',
      border: '2px solid #e0e0e0',
      fontSize: '15px',
      boxSizing: 'border-box',
      outline: 'none',
      transition: 'border-color 0.3s ease'
    },
    button: {
      width: '100%',
      padding: '16px',
      borderRadius: '12px',
      border: 'none',
      background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 100%)',
      color: 'white',
      fontSize: '16px',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'transform 0.2s ease',
      marginTop: '10px'
    },
    error: {
      backgroundColor: '#FEE2E2',
      color: '#DC2626',
      padding: '14px',
      borderRadius: '10px',
      marginBottom: '20px',
      fontSize: '14px',
      textAlign: 'center'
    },
    hint: {
      marginTop: '25px',
      padding: '18px',
      backgroundColor: '#F3E8FF',
      borderRadius: '12px',
      fontSize: '13px',
      color: '#6B46C1'
    },
    hintTitle: {
      fontWeight: '600',
      marginBottom: '8px'
    },
    backLink: {
      display: 'block',
      textAlign: 'center',
      marginTop: '25px',
      color: '#6B46C1',
      textDecoration: 'none',
      fontSize: '14px'
    }
  }

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <div style={styles.header}>
          <h1 style={styles.logo}>Shells Fashion</h1>
          <p style={styles.subtitle}>Painel Administrativo</p>
        </div>

        {error && (
          <div style={styles.error}>{error}</div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Email</label>
            <input
              style={styles.input}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              autoComplete="email"
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Senha</label>
            <input
              style={styles.input}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />
          </div>

          <button 
            type="submit" 
            style={styles.button}
            disabled={loading}
          >
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>

        <div style={styles.hint}>
          <div style={styles.hintTitle}>Credenciais de Teste:</div>
          <div>Email: admin@example.com</div>
          <div>Senha: 123456</div>
        </div>

        <Link to="/" style={styles.backLink}>
          ← Voltar para a loja
        </Link>
      </div>
    </div>
  )
}

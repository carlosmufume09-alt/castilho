import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

const API_URL = 'http://localhost:5000/api'

export default function Home() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadProducts()
  }, [])

  const loadProducts = async () => {
    try {
      const res = await axios.get(`${API_URL}/products`)
      setProducts(res.data.data || [])
    } catch (error) {
      console.error('Erro ao carregar produtos:', error)
    } finally {
      setLoading(false)
    }
  }

  const styles = {
    container: {
      fontFamily: "'Inter', sans-serif",
      minHeight: '100vh',
      backgroundColor: '#f8f9fa'
    },
    header: {
      background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 50%, #9F7AEA 100%)',
      color: 'white',
      padding: '20px 40px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    },
    logo: {
      fontSize: '24px',
      fontWeight: '700',
      fontFamily: "'Playfair Display', serif"
    },
    nav: {
      display: 'flex',
      gap: '30px',
      alignItems: 'center'
    },
    navLink: {
      color: 'white',
      textDecoration: 'none',
      fontSize: '15px',
      opacity: '0.9'
    },
    hero: {
      background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 50%, #9F7AEA 100%)',
      color: 'white',
      padding: '80px 40px',
      textAlign: 'center'
    },
    heroTitle: {
      fontSize: '48px',
      fontWeight: '700',
      fontFamily: "'Playfair Display', serif",
      marginBottom: '20px'
    },
    heroSub: {
      fontSize: '18px',
      opacity: '0.9',
      maxWidth: '600px',
      margin: '0 auto 30px'
    },
    heroBtn: {
      background: 'white',
      color: '#6B46C1',
      padding: '14px 35px',
      borderRadius: '30px',
      textDecoration: 'none',
      fontWeight: '600',
      fontSize: '16px',
      display: 'inline-block'
    },
    section: {
      padding: '60px 40px',
      maxWidth: '1200px',
      margin: '0 auto'
    },
    sectionTitle: {
      fontSize: '32px',
      fontWeight: '700',
      fontFamily: "'Playfair Display', serif",
      textAlign: 'center',
      marginBottom: '40px',
      color: '#1a1a2e'
    },
    productsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
      gap: '25px'
    },
    productCard: {
      backgroundColor: 'white',
      borderRadius: '16px',
      overflow: 'hidden',
      boxShadow: '0 4px 15px rgba(0,0,0,0.08)',
      transition: 'transform 0.3s ease'
    },
    productImage: {
      width: '100%',
      height: '200px',
      backgroundColor: '#f0f0f0',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '64px'
    },
    productInfo: {
      padding: '20px'
    },
    productName: {
      fontSize: '18px',
      fontWeight: '600',
      marginBottom: '8px',
      color: '#1a1a2e'
    },
    productDesc: {
      fontSize: '14px',
      color: '#666',
      marginBottom: '15px',
      lineHeight: '1.5'
    },
    productPrice: {
      fontSize: '22px',
      fontWeight: '700',
      color: '#6B46C1'
    },
    footer: {
      background: 'linear-gradient(135deg, #6B46C1 0%, #805AD5 100%)',
      color: 'white',
      padding: '50px 40px',
      textAlign: 'center'
    },
    footerTitle: {
      fontSize: '24px',
      fontWeight: '700',
      fontFamily: "'Playfair Display', serif",
      marginBottom: '20px'
    },
    footerInfo: {
      display: 'flex',
      justifyContent: 'center',
      gap: '40px',
      marginBottom: '30px',
      flexWrap: 'wrap'
    },
    footerItem: {
      fontSize: '15px',
      opacity: '0.9'
    },
    copyright: {
      fontSize: '14px',
      opacity: '0.7',
      borderTop: '1px solid rgba(255,255,255,0.2)',
      paddingTop: '20px',
      marginTop: '20px'
    }
  }

  return (
    <div style={styles.container}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.logo}>Shells Fashion</div>
        <nav style={styles.nav}>
          <a href="#produtos" style={styles.navLink}>Produtos</a>
          <a href="#contato" style={styles.navLink}>Contato</a>
          <Link to="/login" style={styles.navLink}>Admin</Link>
        </nav>
      </header>

      {/* Hero */}
      <section style={styles.hero}>
        <h1 style={styles.heroTitle}>Elegância Moçambicana</h1>
        <p style={styles.heroSub}>
          Descubra nossa coleção exclusiva de moda elegante. 
          Peças selecionadas com cuidado para oferecer o melhor do estilo africano.
        </p>
        <a href="#produtos" style={styles.heroBtn}>Ver Coleção</a>
      </section>

      {/* Produtos */}
      <section id="produtos" style={styles.section}>
        <h2 style={styles.sectionTitle}>Nossa Coleção</h2>
        
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
            Carregando produtos...
          </div>
        ) : products.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
            Nenhum produto disponível no momento.
          </div>
        ) : (
          <div style={styles.productsGrid}>
            {products.map(product => (
              <div key={product.id} style={styles.productCard}>
                <div style={styles.productImage}>👗</div>
                <div style={styles.productInfo}>
                  <h3 style={styles.productName}>{product.name}</h3>
                  <p style={styles.productDesc}>
                    {product.description?.substring(0, 80)}...
                  </p>
                  <div style={styles.productPrice}>
                    MT {parseFloat(product.price).toFixed(2)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer id="contato" style={styles.footer}>
        <h3 style={styles.footerTitle}>Shells Fashion Elegance</h3>
        <div style={styles.footerInfo}>
          <div style={styles.footerItem}>📱 WhatsApp: +258 879 992 762</div>
          <div style={styles.footerItem}>📞 Tel: 847 052 762</div>
          <div style={styles.footerItem}>📍 Khongolote, Maputo, Moçambique</div>
        </div>
        <a 
          href="https://wa.me/258879992762" 
          target="_blank"
          rel="noopener noreferrer"
          style={{ ...styles.heroBtn, backgroundColor: '#25D366', color: 'white' }}
        >
          Falar no WhatsApp
        </a>
        <p style={styles.copyright}>
          © 2024 Shells Fashion Elegance - Moçambique. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  )
}

const { query } = require('../config/db');

// Listar todos os produtos
exports.getAll = async (req, res) => {
  try {
    const products = await query(
      'SELECT * FROM products WHERE active = 1 ORDER BY created_at DESC'
    );
    
    res.json({
      success: true,
      data: products
    });
  } catch (error) {
    console.error('Erro ao listar produtos:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao listar produtos'
    });
  }
};

// Buscar produto por ID
exports.getById = async (req, res) => {
  try {
    const { id } = req.params;
    const products = await query('SELECT * FROM products WHERE id = ?', [id]);
    
    if (products.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Produto não encontrado'
      });
    }
    
    res.json({
      success: true,
      data: products[0]
    });
  } catch (error) {
    console.error('Erro ao buscar produto:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao buscar produto'
    });
  }
};

// Criar produto
exports.create = async (req, res) => {
  try {
    const { name, description, price, image, category, stock } = req.body;

    if (!name || !price) {
      return res.status(400).json({
        success: false,
        error: 'Nome e preço são obrigatórios'
      });
    }

    const result = await query(
      `INSERT INTO products (name, description, price, image, category, stock) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [name, description || '', price, image || '', category || 'outros', stock || 0]
    );

    res.status(201).json({
      success: true,
      message: 'Produto criado com sucesso',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Erro ao criar produto:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao criar produto'
    });
  }
};

// Atualizar produto
exports.update = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, price, image, category, stock, active } = req.body;

    await query(
      `UPDATE products SET 
        name = COALESCE(?, name),
        description = COALESCE(?, description),
        price = COALESCE(?, price),
        image = COALESCE(?, image),
        category = COALESCE(?, category),
        stock = COALESCE(?, stock),
        active = COALESCE(?, active),
        updated_at = NOW()
       WHERE id = ?`,
      [name, description, price, image, category, stock, active, id]
    );

    res.json({
      success: true,
      message: 'Produto atualizado com sucesso'
    });
  } catch (error) {
    console.error('Erro ao atualizar produto:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao atualizar produto'
    });
  }
};

// Deletar produto
exports.delete = async (req, res) => {
  try {
    const { id } = req.params;
    
    await query('UPDATE products SET active = 0 WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Produto removido com sucesso'
    });
  } catch (error) {
    console.error('Erro ao deletar produto:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao deletar produto'
    });
  }
};

// Buscar por categoria
exports.getByCategory = async (req, res) => {
  try {
    const { category } = req.params;
    const products = await query(
      'SELECT * FROM products WHERE category = ? AND active = 1',
      [category]
    );
    
    res.json({
      success: true,
      data: products
    });
  } catch (error) {
    console.error('Erro ao buscar por categoria:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao buscar produtos'
    });
  }
};

// Pesquisar produtos
exports.search = async (req, res) => {
  try {
    const { q } = req.query;
    const products = await query(
      `SELECT * FROM products 
       WHERE active = 1 AND (name LIKE ? OR description LIKE ?)`,
      [`%${q}%`, `%${q}%`]
    );
    
    res.json({
      success: true,
      data: products
    });
  } catch (error) {
    console.error('Erro na pesquisa:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao pesquisar produtos'
    });
  }
};

const app = require('./app');
const { connectDB } = require('./config/db');

const PORT = process.env.PORT || 5000;

// Conectar ao banco de dados e iniciar servidor
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`
    ╔════════════════════════════════════════════════════════════╗
    ║                                                            ║
    ║   🚀 SHELLS FASHION ELEGANCE - Backend                     ║
    ║                                                            ║
    ║   Servidor rodando em: http://localhost:${PORT}              ║
    ║   Moçambique - Khongolote, Maputo                         ║
    ║                                                            ║
    ╚════════════════════════════════════════════════════════════╝
    `);
  });
}).catch((error) => {
  console.error('Erro ao conectar ao banco de dados:', error);
  process.exit(1);
});
